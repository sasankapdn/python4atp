#!/bin/bash

# Firewall
sudo systemctl disable firewalld

# kill screensaver
sudo killall gnome-screensaver

# setup and start vnc
mkdir .vnc
echo $1|vncpasswd -f > /home/opc/.vnc/passwd
chmod 600 /home/opc/.vnc/passwd
vncserver :1

echo "Developer Workshop Available"
